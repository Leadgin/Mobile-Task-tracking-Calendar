package com.example.miniproject.ui.theme.Screen

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.miniproject.Data.Entity.ProjectEntity
import com.example.miniproject.viewModel.GroupViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectListScreen(
    groupId: String,
    viewModel: GroupViewModel,
    onBack: () -> Unit,
    onEditProject: (String) -> Unit
) {
    val projects by viewModel.getProjectsFlow(groupId).collectAsState(initial = emptyList())

    Scaffold(topBar = {
        TopAppBar(title = { Text("Projects") }, navigationIcon = {
            IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
        })
    }, floatingActionButton = {
        FloatingActionButton(onClick = {
            // create and open new project for edit
            viewModel.addProject(groupId, "New Project", "", 0, "New")
        }) {
            Icon(Icons.Default.Add, contentDescription = "Add Project")
        }
    }) { padding ->
        LazyColumn(modifier = Modifier
            .padding(padding)
            .padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(projects) { project ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(project.title)
                            if (project.description.isNotEmpty()) Text(project.description)
                            Text("Manpower: ${project.manpowerNeeded} Status: ${project.status}")
                        }
                        IconButton(onClick = { onEditProject(project.id) }) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit")
                        }
                    }
                }
            }
        }
    }
}
