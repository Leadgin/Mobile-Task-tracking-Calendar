package com.example.miniproject.Model

import java.lang.reflect.Member
import java.util.UUID

data class Group(
    val id: String = UUID.randomUUID().toString(),
    var name: String,
    var description: String = "",
    val ownerId: String,
    val admins: MutableList<String> = mutableListOf(),
    val members: MutableList<Member> = mutableListOf(),
    var isActive: Boolean = true,
    val projects: MutableList<Project> = mutableListOf()
)
