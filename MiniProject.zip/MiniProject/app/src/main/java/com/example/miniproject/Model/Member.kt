package com.example.miniproject.Model

import java.util.UUID

data class Member(
    val userId: String = UUID.randomUUID().toString(),
    val groupUserId: String = UUID.randomUUID().toString(),
    val name: String,
    var isAdmin: Boolean = false
)
