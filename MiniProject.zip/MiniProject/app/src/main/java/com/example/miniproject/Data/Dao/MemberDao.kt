package com.example.miniproject.Data.Dao

import androidx.room.*
import com.example.miniproject.Data.Entity.MemberEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MemberDao {
    @Insert
    suspend fun insert(member: MemberEntity)

    @Update
    suspend fun update(member: MemberEntity)

    @Query("SELECT * FROM members WHERE groupId = :groupId")
    fun getMembersOfGroup(groupId: String): Flow<List<MemberEntity>>

    @Query("DELETE FROM members WHERE userId = :userId")
    suspend fun deleteById(userId: String)

    @Delete
    suspend fun delete(member: MemberEntity)
}
