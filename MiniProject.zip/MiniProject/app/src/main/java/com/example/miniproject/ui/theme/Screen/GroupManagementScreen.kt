package com.example.miniproject.ui.theme.Screen

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.miniproject.Data.Entity.GroupEntity
import com.example.miniproject.viewModel.GroupViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GroupManagementScreen(
    viewModel: GroupViewModel,
    onBack: () -> Unit,
    onCreateClick: () -> Unit,
    onOpenGroup: (String) -> Unit,
    onOpenMembers: (String) -> Unit,
    onEditGroup: (String) -> Unit
) {
    val groups by viewModel.allGroups.collectAsState()
    var search by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Groups") }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onCreateClick) {
                Icon(Icons.Default.Add, contentDescription = "Create Group")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            TextField(
                value = search,
                onValueChange = { search = it },
                placeholder = { Text("Search groups...") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            val filtered = groups.filter { it.name.contains(search, ignoreCase = true) }

            if (filtered.isEmpty()) {
                Text("No groups yet", fontSize = 16.sp)
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(filtered) { group ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onOpenGroup(group.groupId) },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(group.name, style = MaterialTheme.typography.titleMedium)
                                    if (group.description.isNotEmpty()) Text(group.description, style = MaterialTheme.typography.bodySmall)
                                }
                                Column {
                                    Text("Owner: ${group.ownerId}", style = MaterialTheme.typography.bodySmall)
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row {
                                        TextButton(onClick = { onOpenMembers(group.groupId) }) { Text("Members") }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        TextButton(onClick = { onEditGroup(group.groupId) }) { Text("Edit") }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
