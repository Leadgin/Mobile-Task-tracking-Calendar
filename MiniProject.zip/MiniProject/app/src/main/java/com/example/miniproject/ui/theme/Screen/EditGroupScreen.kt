package com.example.miniproject.ui.theme.Screen

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.miniproject.viewModel.GroupViewModel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditGroupScreen(
    groupId: String,
    viewModel: GroupViewModel,
    onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }

    LaunchedEffect(groupId) {
        viewModel.getGroupByIdFlow(groupId).collect { g ->
            g?.let {
                name = it.name
                description = it.description
            }
        }
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Edit Group") }, navigationIcon = {
            IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
        })
    }) { padding ->
        Column(modifier = Modifier.padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            TextField(value = name, onValueChange = { name = it }, label = { Text("Group Name") })
            TextField(value = description, onValueChange = { description = it }, label = { Text("Description") })
            Button(onClick = {
                scope.launch {
                    val g = viewModel.getGroupByIdFlow(groupId).first()
                    if (g != null) {
                        viewModel.updateGroup(g.copy(name = name, description = description))
                    }
                    onBack()
                }
            }) {
                Text("Save")
            }
            Spacer(modifier = Modifier.height(8.dp))
            Button(onClick = {
                scope.launch {
                    val g = viewModel.getGroupByIdFlow(groupId).first()
                    if (g != null) {
                        viewModel.deactivateGroup(g)
                    }
                    onBack()
                }
            }) {
                Text("Deactivate Group")
            }
        }
    }
}
