package com.example.miniproject.Data.Dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.miniproject.Data.Entity.GroupEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface GroupDao {

    @Insert
    suspend fun insertGroup(group: GroupEntity)

    @Update
    suspend fun updateGroup(group: GroupEntity)

    @Query("SELECT * FROM group_table ORDER BY groupId DESC")
    fun getAllGroups(): Flow<List<GroupEntity>>

    @Query("SELECT * FROM group_table WHERE groupId = :groupId LIMIT 1")
    fun getGroupById(groupId: String): Flow<GroupEntity?>

}