package com.example.miniproject.ui.theme.Screen

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.miniproject.viewModel.GroupViewModel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditProjectScreen(
    projectId: String,
    viewModel: GroupViewModel,
    onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var manpower by remember { mutableStateOf("0") }
    var status by remember { mutableStateOf("") }

    // load project
    LaunchedEffect(projectId) {
        viewModel.getProjectByIdFlow(projectId).collect { p ->
            p?.let {
                title = it.title
                description = it.description
                manpower = it.manpowerNeeded.toString()
                status = it.status
            }
        }
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Edit Project") }, navigationIcon = {
            IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
        })
    }) { padding ->
        Column(modifier = Modifier
            .padding(padding)
            .padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {

            TextField(value = title, onValueChange = { title = it }, label = { Text("Title") })
            TextField(value = description, onValueChange = { description = it }, label = { Text("Description") })
            TextField(value = manpower, onValueChange = { manpower = it.filter { ch -> ch.isDigit() } }, label = { Text("Manpower") })
            TextField(value = status, onValueChange = { status = it }, label = { Text("Status") })

            Spacer(modifier = Modifier.height(12.dp))

            Button(onClick = {
                scope.launch {
                    val existing = viewModel.getProjectByIdFlow(projectId).first()
                    if (existing != null) {
                        val updated = existing.copy(
                            title = title,
                            description = description,
                            manpowerNeeded = manpower.toIntOrNull() ?: 0,
                            status = status
                        )
                        viewModel.updateProject(updated)
                    }
                    onBack()
                }
            }) { Text("Save") }

        }
    }
}
