package com.example.miniproject.ui.theme.Screen

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.miniproject.Data.Entity.GroupEntity
import com.example.miniproject.viewModel.GroupViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GroupDetailsScreen(
    group: GroupEntity,
    viewModel: GroupViewModel,
    onBack: () -> Unit,
    onEditGroup: (GroupEntity) -> Unit,
    onManageMembers: (GroupEntity) -> Unit,
    onManageProjects: (GroupEntity) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(group.name) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Description: ${group.description}")
            Text("Owner ID: ${group.ownerId}")
            Text("Status: ${if(group.isActive) "Active" else "Inactive"}")

            Spacer(Modifier.height(24.dp))

            Button(onClick = { onEditGroup(group) }) { Text("Edit Group") }
            Button(onClick = { onManageMembers(group) }) { Text("Manage Members") }
            Button(onClick = { onManageProjects(group) }) { Text("Manage Projects") }
            Button(onClick = { viewModel.deactivateGroup(group) }) { Text("Deactivate Group") }
        }
    }
}
