package com.example.miniproject.Data.Entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "group_table")
data class GroupEntity(
    @PrimaryKey val groupId: String,
    val name: String,
    val description: String,
    val ownerId: String,
    val isActive: Boolean = true
)
