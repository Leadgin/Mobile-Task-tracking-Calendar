package com.example.miniproject

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.example.miniproject.ui.theme.MiniProjectTheme
import com.example.miniproject.viewModel.GroupViewModel
import com.example.miniproject.viewModel.GroupViewModelFactory

class MainActivity : ComponentActivity() {

    private val groupViewModel: GroupViewModel by viewModels {
        GroupViewModelFactory(application)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MiniProjectTheme {
                AppNavHost(viewModel = groupViewModel)
            }
        }
    }
}
