package com.example.miniproject

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.miniproject.ui.theme.Screen.CreateGroupScreen
import com.example.miniproject.ui.theme.Screen.GroupManagementScreen
import com.example.miniproject.ui.theme.Screen.MemberManagementScreen
import com.example.miniproject.ui.theme.Screen.ProjectListScreen
import com.example.miniproject.ui.theme.Screen.EditProjectScreen
import com.example.miniproject.ui.theme.Screen.EditGroupScreen
import com.example.miniproject.viewModel.GroupViewModel

@Composable
fun AppNavHost(
    viewModel: GroupViewModel
) {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "group_management") {

        composable("group_management") {
            GroupManagementScreen(
                viewModel = viewModel,
                onBack = { /* if you want to handle back */ },
                onCreateClick = { navController.navigate("create_group") },
                onOpenGroup = { groupId -> navController.navigate("project_list/$groupId") },
                onOpenMembers = { groupId -> navController.navigate("members/$groupId") },
                onEditGroup = { groupId -> navController.navigate("edit_group/$groupId") }
            )
        }

        composable("create_group") {
            CreateGroupScreen(onBack = { navController.popBackStack() }, onCreate = { name ->
                viewModel.createGroup(name)
                navController.popBackStack()
            })
        }

        composable(
            "members/{groupId}",
            arguments = listOf(navArgument("groupId") { type = NavType.StringType })
        ) { backStackEntry ->
            val gid = requireNotNull(backStackEntry.arguments?.getString("groupId"))
            MemberManagementScreen(
                groupId = gid,
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }

        composable(
            "project_list/{groupId}",
            arguments = listOf(navArgument("groupId") { type = NavType.StringType })
        ) { backStackEntry ->
            val gid = requireNotNull(backStackEntry.arguments?.getString("groupId"))
            ProjectListScreen(
                groupId = gid,
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onEditProject = { projectId -> navController.navigate("edit_project/${projectId}") }
            )
        }

        composable(
            "edit_project/{projectId}",
            arguments = listOf(navArgument("projectId") { type = NavType.StringType })
        ) { backStackEntry ->
            val pid = requireNotNull(backStackEntry.arguments?.getString("projectId"))
            EditProjectScreen(projectId = pid, viewModel = viewModel, onBack = { navController.popBackStack() })
        }

        composable(
            "edit_group/{groupId}",
            arguments = listOf(navArgument("groupId") { type = NavType.StringType })
        ) { backStackEntry ->
            val gid = requireNotNull(backStackEntry.arguments?.getString("groupId"))
            EditGroupScreen(groupId = gid, viewModel = viewModel, onBack = { navController.popBackStack() })
        }
    }
}
