package com.example.miniproject.Model

data class Project(
    var title: String,
    var description: String,
    var manpowerNeeded: Int,
    var status: String
)
