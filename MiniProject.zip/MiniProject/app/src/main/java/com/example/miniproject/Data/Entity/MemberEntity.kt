package com.example.miniproject.Data.Entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "members")
data class MemberEntity(
    @PrimaryKey val userId: String,
    val groupId: String,  // Foreign key to GroupEntity
    val name: String,
    val isAdmin: Boolean = false
)
