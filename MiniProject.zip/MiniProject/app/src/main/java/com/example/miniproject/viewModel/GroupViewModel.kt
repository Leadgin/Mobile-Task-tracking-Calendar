package com.example.miniproject.viewModel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.miniproject.Data.Database.GroupDatabase
import com.example.miniproject.Data.Entity.GroupEntity
import com.example.miniproject.Data.Entity.MemberEntity
import com.example.miniproject.Data.Entity.ProjectEntity
import com.example.miniproject.Data.Repo.GroupRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.util.UUID


class GroupViewModel(application: Application) : AndroidViewModel(application) {
    private val db = GroupDatabase.getDatabase(application)
    private val repository = GroupRepository(db.groupDao(), db.memberDao(), db.projectDao())

    private val _groups = MutableStateFlow<List<GroupEntity>>(emptyList())
    val allGroups: StateFlow<List<GroupEntity>> = _groups

    // a placeholder current user id — replace with real auth user id if you add auth
    val currentUserId: String = "current-user-id" // you can generate or load from prefs

    init {
        viewModelScope.launch {
            repository.getAllGroups().collectLatest { _groups.value = it }
        }
    }

    // Group
    fun createGroup(name: String, ownerId: String = currentUserId) {
        viewModelScope.launch {
            val group = GroupEntity(
                groupId = UUID.randomUUID().toString(),
                name = name,
                description = "",
                ownerId = ownerId
            )
            repository.createGroup(group)
        }
    }

    fun updateGroup(group: GroupEntity) {
        viewModelScope.launch { repository.updateGroup(group) }
    }

    fun deactivateGroup(group: GroupEntity) {
        val updated = group.copy(isActive = false)
        updateGroup(updated)
    }

    fun getGroupByIdFlow(groupId: String) = repository.getGroupById(groupId)

    // Member
    fun addMember(groupId: String, name: String, isAdmin: Boolean = false) {
        viewModelScope.launch {
            val member = MemberEntity(
                userId = UUID.randomUUID().toString(),
                groupId = groupId,
                name = name,
                isAdmin = isAdmin
            )
            repository.addMember(member)
        }
    }

    fun removeMember(member: MemberEntity) {
        viewModelScope.launch { repository.removeMember(member) }
    }

    fun setAdmin(member: MemberEntity, isAdmin: Boolean) {
        viewModelScope.launch { repository.updateMember(member.copy(isAdmin = isAdmin)) }
    }

    fun getMembersFlow(groupId: String) = repository.getMembers(groupId)

    // Project
    fun addProject(groupId: String, title: String, description: String, manpower: Int, status: String) {
        viewModelScope.launch {
            val project = ProjectEntity(
                id = UUID.randomUUID().toString(),
                groupId = groupId,
                title = title,
                description = description,
                manpowerNeeded = manpower,
                status = status
            )
            repository.addProject(project)
        }
    }

    fun updateProject(project: ProjectEntity) {
        viewModelScope.launch { repository.updateProject(project) }
    }

    fun getProjectsFlow(groupId: String) = repository.getProjects(groupId)
    fun getProjectByIdFlow(projectId: String) = repository.getProjectById(projectId)

    // permission helpers
    fun isOwner(userId: String, group: GroupEntity) = userId == group.ownerId
    fun isAdmin(member: MemberEntity) = member.isAdmin
    suspend fun isOwnerById(groupId: String, userId: String): Boolean {
        val g = repository.getGroupById(groupId).first()
        return g?.ownerId == userId
    }


}
// Factory object to obtain GroupViewModel from activity
object Factory {
    fun getFactory(application: Application): ViewModelProvider.Factory {
        return object : ViewModelProvider.AndroidViewModelFactory(application) {
            // default AndroidViewModelFactory works fine
        }
    }
}
