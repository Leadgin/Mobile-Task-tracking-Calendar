package com.example.miniproject.Data.Database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.miniproject.Data.Dao.GroupDao
import com.example.miniproject.Data.Dao.MemberDao
import com.example.miniproject.Data.Dao.ProjectDao
import com.example.miniproject.Data.Entity.GroupEntity
import com.example.miniproject.Data.Entity.MemberEntity
import com.example.miniproject.Data.Entity.ProjectEntity

@Database(
    entities = [GroupEntity::class, MemberEntity::class, ProjectEntity::class],
    version = 1,
    exportSchema = false
)
abstract class GroupDatabase : RoomDatabase() {
    abstract fun groupDao(): GroupDao
    abstract fun memberDao(): MemberDao
    abstract fun projectDao(): ProjectDao

    companion object {
        @Volatile
        private var INSTANCE: GroupDatabase? = null

        fun getDatabase(context: Context): GroupDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    GroupDatabase::class.java,
                    "group_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
