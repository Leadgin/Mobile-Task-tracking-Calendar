package com.example.miniproject.Data.Dao

import androidx.room.*
import com.example.miniproject.Data.Entity.ProjectEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ProjectDao {
    @Insert
    suspend fun insert(project: ProjectEntity)

    @Update
    suspend fun update(project: ProjectEntity)

    @Query("SELECT * FROM projects WHERE groupId = :groupId")
    fun getProjectsOfGroup(groupId: String): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE id = :projectId LIMIT 1")
    fun getProjectById(projectId: String): Flow<ProjectEntity?>
}
