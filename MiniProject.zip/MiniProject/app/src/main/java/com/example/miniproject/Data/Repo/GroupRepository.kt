package com.example.miniproject.Data.Repo

import com.example.miniproject.Data.Dao.GroupDao
import com.example.miniproject.Data.Dao.MemberDao
import com.example.miniproject.Data.Dao.ProjectDao
import com.example.miniproject.Data.Entity.GroupEntity
import com.example.miniproject.Data.Entity.MemberEntity
import com.example.miniproject.Data.Entity.ProjectEntity
import kotlinx.coroutines.flow.Flow

class GroupRepository(
    private val groupDao: GroupDao,
    private val memberDao: MemberDao,
    private val projectDao: ProjectDao
) {
    // Group
    suspend fun createGroup(group: GroupEntity) = groupDao.insertGroup(group)
    suspend fun updateGroup(group: GroupEntity) = groupDao.updateGroup(group)
    fun getAllGroups(): Flow<List<GroupEntity>> = groupDao.getAllGroups()
    fun getGroupById(groupId: String): Flow<GroupEntity?> = groupDao.getGroupById(groupId)

    // Member
    suspend fun addMember(member: MemberEntity) = memberDao.insert(member)
    suspend fun updateMember(member: MemberEntity) = memberDao.update(member)
    fun getMembers(groupId: String): Flow<List<MemberEntity>> = memberDao.getMembersOfGroup(groupId)
    suspend fun removeMember(member: MemberEntity) = memberDao.delete(member)
    suspend fun removeMemberById(userId: String) = memberDao.deleteById(userId)

    // Project
    suspend fun addProject(project: ProjectEntity) = projectDao.insert(project)
    suspend fun updateProject(project: ProjectEntity) = projectDao.update(project)
    fun getProjects(groupId: String): Flow<List<ProjectEntity>> = projectDao.getProjectsOfGroup(groupId)
    fun getProjectById(projectId: String): Flow<ProjectEntity?> = projectDao.getProjectById(projectId)
}
