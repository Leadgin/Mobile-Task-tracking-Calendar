package com.example.miniproject.Data.Entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val groupId: String,
    var title: String,
    var description: String,
    var manpowerNeeded: Int,
    var status: String
)
