package com.example.miniproject.ui.theme.Screen

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.miniproject.Data.Entity.MemberEntity
import com.example.miniproject.viewModel.GroupViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MemberManagementScreen(
    groupId: String,
    viewModel: GroupViewModel,
    onBack: () -> Unit
) {
    val members by viewModel.getMembersFlow(groupId).collectAsState(initial = emptyList())
    var newMemberName by remember { mutableStateOf("") }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Members") }, navigationIcon = {
            IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
        })
    }) { padding ->
        Column(modifier = Modifier.padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row {
                TextField(
                    value = newMemberName,
                    onValueChange = { newMemberName = it },
                    label = { Text("New Member Name") },
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(8.dp))
                Button(onClick = {
                    if (newMemberName.isNotBlank()) {
                        viewModel.addMember(groupId, newMemberName)
                        newMemberName = ""
                    }
                }) {
                    Text("Add")
                }
            }

            Spacer(Modifier.height(12.dp))

            if (members.isEmpty()) {
                Text("No members yet")
            } else {
                LazyColumn {
                    items(members) { member: MemberEntity ->
                        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(member.name, modifier = Modifier.weight(1f))
                            Checkbox(checked = member.isAdmin, onCheckedChange = { checked ->
                                viewModel.setAdmin(member, checked)
                            })
                            IconButton(onClick = { viewModel.removeMember(member) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Remove")
                            }
                        }
                    }
                }
            }
        }
    }
}
